import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
  Alert,
  Modal,
  TextInput,
  ScrollView,
  ActivityIndicator,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useSQLiteContext } from "expo-sqlite";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { format, parseISO } from "date-fns";
import { ru } from "date-fns/locale";

import {
  getAllTasks,
  createTask,
  updateTask,
  deleteTask,
  Task,
} from "@/db";
import { colors, spacing, radius, fontSize, shadow } from "@/theme";
import { TASK_TYPES, TaskType } from "@/config";

const FILTERS = [
  { key: "all", label: "Все" },
  { key: "homework", label: "Домашние" },
  { key: "deadline", label: "Дедлайны" },
  { key: "exam", label: "Экзамены" },
  { key: "session", label: "Сессия" },
];

function TaskItem({
  task,
  onToggle,
  onDelete,
}: {
  task: Task;
  onToggle: () => void;
  onDelete: () => void;
}) {
  const typeInfo = TASK_TYPES[task.type] ?? TASK_TYPES.homework;
  const dateStr = format(parseISO(task.date), "d MMM yyyy", { locale: ru });
  return (
    <View style={[styles.taskCard, shadow.card]}>
      <TouchableOpacity style={styles.checkbox} onPress={onToggle}>
        <Ionicons
          name={task.completed ? "checkmark-circle" : "ellipse-outline"}
          size={24}
          color={task.completed ? colors.success : colors.textSecondary}
        />
      </TouchableOpacity>
      <View style={styles.taskBody}>
        <Text
          style={[styles.taskTitle, task.completed && styles.taskDone]}
          numberOfLines={2}
        >
          {task.title}
        </Text>
        <View style={styles.taskMeta}>
          <View
            style={[
              styles.typeBadge,
              { backgroundColor: typeInfo.color + "20" },
            ]}
          >
            <Text style={[styles.typeBadgeText, { color: typeInfo.color }]}>
              {typeInfo.label}
            </Text>
          </View>
          <Text style={styles.metaText}>{task.subject}</Text>
          <Text style={styles.metaText}>·</Text>
          <Text style={styles.metaText}>{dateStr}</Text>
        </View>
      </View>
      <TouchableOpacity style={styles.deleteBtn} onPress={onDelete}>
        <Ionicons
          name="trash-outline"
          size={18}
          color={colors.textSecondary}
        />
      </TouchableOpacity>
    </View>
  );
}

export default function TasksScreen() {
  const db = useSQLiteContext();
  const queryClient = useQueryClient();
  const [filter, setFilter] = useState("all");
  const [showAdd, setShowAdd] = useState(false);
  const [newTitle, setNewTitle] = useState("");
  const [newSubject, setNewSubject] = useState("");
  const [newType, setNewType] = useState<TaskType>("homework");
  const [newDate, setNewDate] = useState(
    new Date().toISOString().split("T")[0]
  );
  const [isSaving, setIsSaving] = useState(false);

  const { data: tasks = [], refetch } = useQuery<Task[]>({
    queryKey: ["tasks"],
    queryFn: () => getAllTasks(db),
  });

  const invalidate = () => {
    queryClient.invalidateQueries({ queryKey: ["tasks"] });
    queryClient.invalidateQueries({ queryKey: ["stats"] });
  };

  const handleToggle = (task: Task) => {
    updateTask(db, task.id, { completed: !task.completed });
    invalidate();
  };

  const handleDelete = (id: string) => {
    Alert.alert("Удалить задачу?", "Это действие нельзя отменить", [
      { text: "Отмена", style: "cancel" },
      {
        text: "Удалить",
        style: "destructive",
        onPress: () => {
          deleteTask(db, id);
          invalidate();
        },
      },
    ]);
  };

  const handleAdd = () => {
    if (!newTitle.trim()) {
      Alert.alert("Ошибка", "Введите название задачи");
      return;
    }
    setIsSaving(true);
    try {
      createTask(db, {
        title: newTitle.trim(),
        description: null,
        date: new Date(newDate + "T12:00:00").toISOString(),
        type: newType,
        subject: newSubject.trim() || "Общее",
        completed: false,
        notificationDays: 1,
        source: "manual",
      });
      invalidate();
      setShowAdd(false);
      setNewTitle("");
      setNewSubject("");
      setNewType("homework");
      setNewDate(new Date().toISOString().split("T")[0]);
    } finally {
      setIsSaving(false);
    }
  };

  const filtered =
    filter === "all" ? tasks : tasks.filter((t) => t.type === filter);

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.header}>
        <Text style={styles.heading}>Задачи</Text>
        <TouchableOpacity
          style={styles.addBtn}
          onPress={() => setShowAdd(true)}
        >
          <Ionicons name="add" size={22} color={colors.white} />
        </TouchableOpacity>
      </View>

      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.filters}
      >
        {FILTERS.map((f) => (
          <TouchableOpacity
            key={f.key}
            style={[
              styles.filterChip,
              filter === f.key && styles.filterActive,
            ]}
            onPress={() => setFilter(f.key)}
          >
            <Text
              style={[
                styles.filterText,
                filter === f.key && styles.filterTextActive,
              ]}
            >
              {f.label}
            </Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      <FlatList
        data={filtered}
        keyExtractor={(t) => t.id}
        renderItem={({ item }) => (
          <TaskItem
            task={item}
            onToggle={() => handleToggle(item)}
            onDelete={() => handleDelete(item.id)}
          />
        )}
        contentContainerStyle={styles.list}
        ListEmptyComponent={
          <View style={styles.empty}>
            <Ionicons
              name="checkmark-done-outline"
              size={40}
              color={colors.textSecondary}
            />
            <Text style={styles.emptyText}>Задач нет</Text>
          </View>
        }
      />

      <Modal
        visible={showAdd}
        animationType="slide"
        presentationStyle="pageSheet"
        onRequestClose={() => setShowAdd(false)}
      >
        <SafeAreaView style={styles.modal}>
          <View style={styles.modalHeader}>
            <Text style={styles.modalTitle}>Новая задача</Text>
            <TouchableOpacity onPress={() => setShowAdd(false)}>
              <Ionicons name="close" size={24} color={colors.text} />
            </TouchableOpacity>
          </View>

          <ScrollView contentContainerStyle={styles.modalContent}>
            <View style={styles.field}>
              <Text style={styles.label}>Название *</Text>
              <TextInput
                style={styles.input}
                value={newTitle}
                onChangeText={setNewTitle}
                placeholder="Например: Реферат по математике"
                placeholderTextColor={colors.textSecondary}
              />
            </View>

            <View style={styles.field}>
              <Text style={styles.label}>Предмет</Text>
              <TextInput
                style={styles.input}
                value={newSubject}
                onChangeText={setNewSubject}
                placeholder="Например: Математика"
                placeholderTextColor={colors.textSecondary}
              />
            </View>

            <View style={styles.field}>
              <Text style={styles.label}>Тип</Text>
              <View style={styles.typeRow}>
                {(Object.keys(TASK_TYPES) as TaskType[]).map((k) => (
                  <TouchableOpacity
                    key={k}
                    style={[
                      styles.typeChip,
                      newType === k && {
                        backgroundColor: TASK_TYPES[k].color,
                        borderColor: TASK_TYPES[k].color,
                      },
                    ]}
                    onPress={() => setNewType(k)}
                  >
                    <Text
                      style={[
                        styles.typeChipText,
                        newType === k && { color: colors.white },
                      ]}
                    >
                      {TASK_TYPES[k].label}
                    </Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>

            <View style={styles.field}>
              <Text style={styles.label}>Дата (ГГГГ-ММ-ДД)</Text>
              <TextInput
                style={styles.input}
                value={newDate}
                onChangeText={setNewDate}
                placeholder="2026-06-01"
                placeholderTextColor={colors.textSecondary}
                keyboardType="numeric"
              />
            </View>

            <TouchableOpacity
              style={[styles.submitBtn, isSaving && styles.btnDisabled]}
              onPress={handleAdd}
              disabled={isSaving}
            >
              {isSaving ? (
                <ActivityIndicator color={colors.white} />
              ) : (
                <Text style={styles.submitBtnText}>Добавить задачу</Text>
              )}
            </TouchableOpacity>
          </ScrollView>
        </SafeAreaView>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingHorizontal: spacing.lg,
    paddingVertical: spacing.md,
  },
  heading: { fontSize: fontSize.xxl, fontWeight: "600", color: colors.text },
  addBtn: {
    backgroundColor: colors.primary,
    width: 36,
    height: 36,
    borderRadius: radius.full,
    justifyContent: "center",
    alignItems: "center",
  },
  filters: {
    paddingHorizontal: spacing.lg,
    gap: spacing.sm,
    paddingBottom: spacing.sm,
  },
  filterChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: 6,
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.card,
  },
  filterActive: { backgroundColor: colors.primary, borderColor: colors.primary },
  filterText: { fontSize: fontSize.sm, color: colors.textSecondary },
  filterTextActive: { color: colors.white, fontWeight: "500" },
  list: { padding: spacing.lg, gap: spacing.sm },
  taskCard: {
    flexDirection: "row",
    backgroundColor: colors.card,
    borderRadius: radius.md,
    padding: spacing.md,
    alignItems: "center",
    gap: spacing.sm,
    borderWidth: 1,
    borderColor: colors.border,
  },
  checkbox: { padding: 2 },
  taskBody: { flex: 1, gap: 4 },
  taskTitle: { fontSize: fontSize.md, color: colors.text, fontWeight: "500" },
  taskDone: { textDecorationLine: "line-through", color: colors.textSecondary },
  taskMeta: {
    flexDirection: "row",
    alignItems: "center",
    gap: spacing.xs,
    flexWrap: "wrap",
  },
  typeBadge: {
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: radius.sm,
  },
  typeBadgeText: { fontSize: fontSize.xs, fontWeight: "600" },
  metaText: { fontSize: fontSize.xs, color: colors.textSecondary },
  deleteBtn: { padding: spacing.xs },
  empty: { alignItems: "center", paddingTop: 60, gap: spacing.md },
  emptyText: { fontSize: fontSize.md, color: colors.textSecondary },
  modal: { flex: 1, backgroundColor: colors.background },
  modalHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: spacing.lg,
    borderBottomWidth: 1,
    borderBottomColor: colors.border,
  },
  modalTitle: { fontSize: fontSize.lg, fontWeight: "600", color: colors.text },
  modalContent: { padding: spacing.lg, gap: spacing.md },
  field: { gap: spacing.xs },
  label: { fontSize: fontSize.sm, fontWeight: "500", color: colors.text },
  input: {
    borderWidth: 1,
    borderColor: colors.border,
    borderRadius: radius.sm,
    paddingHorizontal: spacing.md,
    paddingVertical: 12,
    fontSize: fontSize.md,
    color: colors.text,
    backgroundColor: colors.background,
  },
  typeRow: { flexDirection: "row", flexWrap: "wrap", gap: spacing.sm },
  typeChip: {
    paddingHorizontal: spacing.md,
    paddingVertical: 8,
    borderRadius: radius.full,
    borderWidth: 1,
    borderColor: colors.border,
    backgroundColor: colors.card,
  },
  typeChipText: { fontSize: fontSize.sm, color: colors.text },
  submitBtn: {
    backgroundColor: colors.primary,
    borderRadius: radius.sm,
    paddingVertical: 14,
    alignItems: "center",
    marginTop: spacing.md,
  },
  btnDisabled: { opacity: 0.5 },
  submitBtnText: { color: colors.white, fontSize: fontSize.md, fontWeight: "600" },
});
