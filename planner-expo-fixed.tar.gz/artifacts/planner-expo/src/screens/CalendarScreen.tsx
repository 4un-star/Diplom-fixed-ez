import React, { useState, useMemo } from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  TouchableOpacity,
} from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { useSQLiteContext } from "expo-sqlite";
import { Calendar, LocaleConfig } from "react-native-calendars";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Ionicons } from "@expo/vector-icons";
import { format, parseISO } from "date-fns";
import { ru } from "date-fns/locale";

import { getAllTasks, updateTask, Task } from "@/db";
import { colors, spacing, radius, fontSize, shadow } from "@/theme";
import { TASK_TYPES } from "@/config";

LocaleConfig.locales["ru"] = {
  monthNames: [
    "Январь","Февраль","Март","Апрель","Май","Июнь",
    "Июль","Август","Сентябрь","Октябрь","Ноябрь","Декабрь",
  ],
  monthNamesShort: [
    "Янв","Фев","Мар","Апр","Май","Июн",
    "Июл","Авг","Сен","Окт","Ноя","Дек",
  ],
  dayNames: ["Воскресенье","Понедельник","Вторник","Среда","Четверг","Пятница","Суббота"],
  dayNamesShort: ["Вс","Пн","Вт","Ср","Чт","Пт","Сб"],
  today: "Сегодня",
};
LocaleConfig.defaultLocale = "ru";

function toDateKey(iso: string): string {
  return iso.split("T")[0];
}

export default function CalendarScreen() {
  const db = useSQLiteContext();
  const queryClient = useQueryClient();
  const today = toDateKey(new Date().toISOString());
  const [selected, setSelected] = useState(today);

  const { data: tasks = [] } = useQuery<Task[]>({
    queryKey: ["tasks"],
    queryFn: () => getAllTasks(db),
  });

  const handleToggle = (task: Task) => {
    updateTask(db, task.id, { completed: !task.completed });
    queryClient.invalidateQueries({ queryKey: ["tasks"] });
    queryClient.invalidateQueries({ queryKey: ["stats"] });
  };

  const markedDates = useMemo(() => {
    const marks: Record<string, any> = {};
    for (const task of tasks) {
      const key = toDateKey(task.date);
      const color = TASK_TYPES[task.type]?.color ?? colors.primary;
      if (!marks[key]) marks[key] = { dots: [], marked: true };
      if (marks[key].dots.length < 3) {
        marks[key].dots.push({ color, selectedColor: color });
      }
    }
    if (marks[selected]) {
      marks[selected] = {
        ...marks[selected],
        selected: true,
        selectedColor: colors.primary,
      };
    } else {
      marks[selected] = { selected: true, selectedColor: colors.primary };
    }
    return marks;
  }, [tasks, selected]);

  const dayTasks = tasks
    .filter((t) => toDateKey(t.date) === selected)
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  const selectedLabel = (() => {
    try {
      return format(parseISO(selected + "T12:00:00"), "d MMMM yyyy", {
        locale: ru,
      });
    } catch {
      return selected;
    }
  })();

  return (
    <SafeAreaView style={styles.safe}>
      <View style={styles.heading}>
        <Text style={styles.headingText}>Календарь</Text>
      </View>

      <Calendar
        current={today}
        onDayPress={(day) => setSelected(day.dateString)}
        markedDates={markedDates}
        markingType="multi-dot"
        theme={{
          backgroundColor: colors.background,
          calendarBackground: colors.card,
          selectedDayBackgroundColor: colors.primary,
          selectedDayTextColor: colors.white,
          todayTextColor: colors.primary,
          dayTextColor: colors.text,
          textDisabledColor: colors.border,
          arrowColor: colors.primary,
          monthTextColor: colors.text,
          textMonthFontWeight: "600",
          textDayFontSize: 14,
          textMonthFontSize: 16,
          textDayHeaderFontSize: 12,
        }}
        style={styles.calendar}
      />

      <View style={styles.daySection}>
        <Text style={styles.dayLabel}>{selectedLabel}</Text>
        {dayTasks.length === 0 ? (
          <View style={styles.empty}>
            <Ionicons
              name="calendar-outline"
              size={32}
              color={colors.textSecondary}
            />
            <Text style={styles.emptyText}>Нет задач на этот день</Text>
          </View>
        ) : (
          <FlatList
            data={dayTasks}
            keyExtractor={(t) => t.id}
            renderItem={({ item }) => {
              const typeInfo = TASK_TYPES[item.type] ?? TASK_TYPES.homework;
              return (
                <TouchableOpacity
                  style={[styles.dayTask, shadow.card]}
                  onPress={() => handleToggle(item)}
                  activeOpacity={0.7}
                >
                  <View
                    style={[
                      styles.dayTaskBar,
                      { backgroundColor: typeInfo.color },
                    ]}
                  />
                  <View style={styles.dayTaskBody}>
                    <Text
                      style={[
                        styles.dayTaskTitle,
                        item.completed && styles.done,
                      ]}
                      numberOfLines={1}
                    >
                      {item.title}
                    </Text>
                    <Text style={styles.dayTaskSub}>
                      {item.subject} · {typeInfo.label}
                    </Text>
                  </View>
                  <Ionicons
                    name={
                      item.completed
                        ? "checkmark-circle"
                        : "ellipse-outline"
                    }
                    size={22}
                    color={
                      item.completed ? colors.success : colors.textSecondary
                    }
                  />
                </TouchableOpacity>
              );
            }}
            contentContainerStyle={styles.dayList}
          />
        )}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: colors.background },
  heading: {
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
    paddingBottom: spacing.sm,
  },
  headingText: {
    fontSize: fontSize.xxl,
    fontWeight: "600",
    color: colors.text,
  },
  calendar: { borderBottomWidth: 1, borderBottomColor: colors.border },
  daySection: {
    flex: 1,
    paddingHorizontal: spacing.lg,
    paddingTop: spacing.md,
  },
  dayLabel: {
    fontSize: fontSize.md,
    fontWeight: "600",
    color: colors.text,
    marginBottom: spacing.sm,
  },
  dayList: { gap: spacing.sm },
  dayTask: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: colors.card,
    borderRadius: radius.md,
    borderWidth: 1,
    borderColor: colors.border,
    overflow: "hidden",
    gap: spacing.sm,
    paddingRight: spacing.md,
  },
  dayTaskBar: { width: 4, alignSelf: "stretch" },
  dayTaskBody: { flex: 1, paddingVertical: spacing.md, gap: 2 },
  dayTaskTitle: { fontSize: fontSize.md, fontWeight: "500", color: colors.text },
  done: { textDecorationLine: "line-through", color: colors.textSecondary },
  dayTaskSub: { fontSize: fontSize.xs, color: colors.textSecondary },
  empty: { alignItems: "center", paddingTop: spacing.xl, gap: spacing.md },
  emptyText: { fontSize: fontSize.sm, color: colors.textSecondary },
});
