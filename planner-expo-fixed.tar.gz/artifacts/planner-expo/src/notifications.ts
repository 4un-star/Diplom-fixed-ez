import * as Notifications from "expo-notifications";
import { Task } from "@/db";

Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
  }),
});

export async function requestNotificationPermissions(): Promise<boolean> {
  const { status } = await Notifications.requestPermissionsAsync();
  return status === "granted";
}

export async function notifyScheduleChange(changes: string[]): Promise<void> {
  if (changes.length === 0) return;
  await Notifications.scheduleNotificationAsync({
    content: {
      title: "Изменение в расписании!",
      body: changes.slice(0, 3).join("\n"),
      data: { type: "schedule_change" },
    },
    trigger: null,
  });
}

export async function cancelAllDeadlineNotifications(): Promise<void> {
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  await Promise.all(
    scheduled
      .filter((n) => n.content.data?.type === "deadline")
      .map((n) => Notifications.cancelScheduledNotificationAsync(n.identifier))
  );
}

export async function scheduleDeadlineNotifications(
  tasks: Task[]
): Promise<void> {
  await cancelAllDeadlineNotifications();

  const now = new Date();

  for (const task of tasks) {
    if (task.completed) continue;

    const dueDate = new Date(task.date);
    const notifyDate = new Date(
      dueDate.getTime() - task.notificationDays * 24 * 60 * 60 * 1000
    );

    if (notifyDate <= now) continue;

    const daysLeft = Math.ceil(
      (dueDate.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
    );

    try {
      await Notifications.scheduleNotificationAsync({
        content: {
          title:
            daysLeft === 0
              ? `Сегодня дедлайн: ${task.title}`
              : `Дедлайн через ${daysLeft} дн.: ${task.title}`,
          body: `Предмет: ${task.subject}`,
          data: { type: "deadline", taskId: task.id },
        },
        trigger: {
          type: Notifications.SchedulableTriggerInputTypes.DATE,
          date: notifyDate,
        },
      });
    } catch {}
  }
}
